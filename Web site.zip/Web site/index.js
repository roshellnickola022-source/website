export default function Home() {
  return (
    <div className="container">
      <h1>PARADISE ROLEPLAY</h1>
      <p className="desc">
        Paradise Roleplay is a realistic SA:MP roleplay server focused on
        serious RP, fair administration, and an enjoyable community experience.
      </p>

      <div className="box">
        <h2>Server Information</h2>
        <p><b>IP:</b> 151.243.226.80:7777</p>
        <p><b>Mode:</b> Roleplay</p>
        <p><b>Status:</b> Online 24/7</p>
      </div>

      <div className="box">
        <h2>Community</h2>
        <a href="https://discord.gg/aGsPf4wJ8" target="_blank">Join Discord</a>
        <br />
        <a href="https://chat.whatsapp.com/BuAivI0znSIAt1fEN3adWU" target="_blank">
          WhatsApp Community
        </a>
      </div>

      <div className="box">
        <h2>RP Basic Rules</h2>
        <ul>
          <li>No Deathmatch (DM)</li>
          <li>No Metagaming / Powergaming</li>
          <li>Respect all players and admins</li>
          <li>Use realistic roleplay at all times</li>
          <li>Follow admin instructions</li>
        </ul>
      </div>

      <a className="btn" href="/whitelist">Apply for Whitelist</a>
    </div>
  );
}